
-- PART 1
-- TASK: Create a dimension model for patients
-- Reference raw_patients and stg_claims
-- Enrich patients with:
--   - First claim date
--   - Total number of claims
--   - Total claim amount
--   - Days since first claim



with patients as (
    select * from {{ ref('raw_patients') }}
),
 -- Add your logic here to join with stg_claims

claims_agg as (
    select
        patient_id,
        min(claim_date) as first_claim_date,
        count(*) as total_claims,
        sum(claim_amount) as total_claim_amount
    from {{ ref('stg_claims') }}
    group by patient_id
),

final as (
    select
        p.*,
        c.first_claim_date,
        c.total_claims,
        c.total_claim_amount,
        datediff(day, c.first_claim_date, current_date) as days_since_first_claim
    from patients p
    left join claims_agg c
        on p.patient_id = c.patient_id
)

select * from final

