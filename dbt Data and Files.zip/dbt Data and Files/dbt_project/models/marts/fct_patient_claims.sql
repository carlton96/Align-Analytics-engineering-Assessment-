

with distinct_claims as (
    select distinct
        claim_id,
        patient_id,
        claim_date,
        claim_amount
    from {{ ref('stg_claims') }} 
),

patient_claim_summary as (
    select
        patient_id,
        count(claim_id) as total_claims,
        sum(claim_amount) as total_claim_amount,
        min(claim_date) as first_claim_date,
        max(claim_date) as last_claim_date
    from distinct_claims
    group by patient_id
)

select * from patient_claim_summary
